package com.onlinemeetingbookingsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeMeetApplicationTests {

    @Test
    void contextLoads() {
    }

}
