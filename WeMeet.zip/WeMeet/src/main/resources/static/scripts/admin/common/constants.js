// This file can contain common constants, e.g., API endpoints, configuration values.
// Example:
// export const API_BASE_URL = '/api/v1';
// export const MAX_ITEMS_PER_PAGE = 20;
